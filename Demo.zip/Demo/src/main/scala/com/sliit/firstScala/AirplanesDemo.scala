package com.sliit.firstScala


import org.apache.spark.{SparkConf, SparkContext}

object AirplanesDemo {

  def main(args: Array[String]): Unit = {

    //Creating the connection
    val sc = new SparkContext(new SparkConf().setAppName("Demo").setMaster("local[*]"))
    val airportsData = sc.textFile("airports.txt");

    // filter data
    val airports = airportsData.filter(line => line.split(",")(3).toFloat>40)


    // map filtered data
    val airportNameAndAltitude = airports.map(line =>{

        val words = line.split(",")
        words(2)+","+ words(3)


    })

    // The result will be output to the text file named 'airportByAltitude'
    airportNameAndAltitude.saveAsTextFile("airportByAltitude.txt")


  }

}


