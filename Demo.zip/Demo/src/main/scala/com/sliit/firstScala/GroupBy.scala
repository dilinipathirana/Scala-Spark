package com.sliit.firstScala

import org.apache.spark.{SparkConf, SparkContext}

object GroupBy {

  def main(args: Array[String]): Unit = {

    //Creating the connection
    val sc = new SparkContext(new SparkConf().setAppName("Demo").setMaster("local[*]"))
    val airportsData = sc.textFile("airports.txt");


    val airportAndTypePair = airportsData.map(line=> (line.split(",")(1),line.split(",")(2)))

    val airportByType = airportAndTypePair.groupByKey()

    for ((airportType, airport)<-airportByType.collectAsMap())
      println(airportType + "  :  "+ airport.toList )
  }
}
