package com.sliit.firstScala

import org.apache.spark.{SparkConf, SparkContext}

object AverageElevation {

  def main(args: Array[String]): Unit = {
    //Creating the connection
    val sc = new SparkContext(new SparkConf().setAppName("Demo").setMaster("local[*]"))
    val Data = sc.textFile("RealEstate.csv");

    val cleanedLines = Data.filter(line => !line.contains("Bedrooms"))

    // split data
    val housePriceRDD= cleanedLines.map(line =>( line.split(",")(4),(1,line.split(",")(9).toDouble)))


    val housePriceTotal = housePriceRDD.reduceByKey((x,y) => (x._1+ y._1 , x._2+y._2))

    val housePriceAvg = housePriceTotal.mapValues(avgCount => avgCount._2 / avgCount._1)


    for((bedroom , avg)<- housePriceAvg.collect()) println(bedroom + "  :  " + avg)



  }
}
