package com.sliit.firstScala

import org.apache.spark.{SparkConf, SparkContext}

object SortBy {

  def main(args: Array[String]): Unit = {

    //Creating the connection
    val sc = new SparkContext(new SparkConf().setAppName("Demo").setMaster("local[*]"))
    val airportsData = sc.textFile("airports.txt");


    val cleanedLines = airportsData.filter(lines => lines.contains("small_airport"))
    val ElevatonPairRdd = cleanedLines.map(line=> (line.split(",") (1),line.split(",")(3).toDouble))

    //this will sort out by the value, bt before it we need to convert the 2nd element into double, float or int value.
    //collect ---> this will make the rdd into an array
    

    val airportByType = ElevatonPairRdd.collect.toSeq.sortBy(_._2)


    for ((airportType, altitude)<-airportByType)
      println(airportType + "  :  "+ altitude )




  }
}
