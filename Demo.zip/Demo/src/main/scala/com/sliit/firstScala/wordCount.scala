package com.sliit.firstScala

import org.apache.spark.{SparkConf, SparkContext}

object wordCount {

  def main(args: Array[String]): Unit = {

    //Creating the connection
    val sc = new SparkContext(new SparkConf().setAppName("Demo").setMaster("local[*]"))
    val airportsData = sc.textFile("airports.txt");

    val lines = airportsData.map(line =>line.split(",")(2))
    val count = lines.countByValue()

    for ((word , count)<- count)
      println(word + "  has "+count+ "  counts")

  }

}
