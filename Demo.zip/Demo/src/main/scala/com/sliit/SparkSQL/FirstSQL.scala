package com.sliit.SparkSQL

import org.apache.log4j.{Level, Logger}
import org.apache.spark.sql.SparkSession
object FirstSQL {


  val AGE_MIDPOINT = "age_midpoint";
  val SALALRY_MIDPOINT = "salary_midpoint";
  val SALARY_MIDPOINT_BUCKET ="salary_midpoint_bucket";

  def main(args: Array[String]): Unit = {

    Logger.getLogger("org").setLevel(Level.ERROR);
    val session = SparkSession.builder().appName("StackOverflowSurvey").master("local[1]").getOrCreate();

    val dataFrameReader =session.read;


    val responses = dataFrameReader.option("header", "true").option("inferSchema",value = "true").csv("2016 Stack Overflow Survey Responses.csv")
    System.out.println("================ Print of Schema ====================");
    responses.printSchema()


    val responseWithSelectedColumns = responses.select("country","Occupation",AGE_MIDPOINT,SALALRY_MIDPOINT)
    System.out.println("================ Print with selected columns ====================");
    responseWithSelectedColumns.show();

    System.out.println("================ Print with response of Afghanistan ====================");
    responseWithSelectedColumns.filter(responseWithSelectedColumns.col("country").===("Afghanistan")).show();




  }


}
